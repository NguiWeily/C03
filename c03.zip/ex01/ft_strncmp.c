/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/26 09:33:48 by wngui             #+#    #+#             */
/*   Updated: 2023/06/26 09:42:42 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strncmp(char *s1, char *s2, unsigned int n)
{
	while (n > 0 && (*s1 == *s2))
	{
		if (*s1 == '\0')
			return (0);
		s1++;
		s2++;
		n--;
	}
	if (n == 0)
		return (0);
	return (*s1 - *s2);
}
/*
#include <stdio.h>

int main()
{
    char str1[] = "Hello";
    char str2[] = "Hell";
    unsigned int n = 5;

    int result = ft_strncmp(str1, str2, n);

    printf("Comparison result: %d\n", result);

    return 0;
}*/
