/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/26 09:29:06 by wngui             #+#    #+#             */
/*   Updated: 2023/06/26 09:30:11 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_strcmp(char *s1, char *s2)
{
	while (*s1 && (*s1 == *s2))
	{
		s1++;
		s2++;
	}
	return ((unsigned char)*s1 - (unsigned char)*s2);
}
/*
int main() {
	char *s1 = "Hello";
	char *s2 = "Hello";
	char *s3 = "World";

	int result1 = ft_strcmp(s1, s2); // returns 0
	int result2 = ft_strcmp(s1, s3); // returns a negative value
	int result3 = ft_strcmp(s3, s1); // returns a positive value

	printf("Result 1: %d\n", result1);
	printf("Result 2: %d\n", result2);
	printf("Result 3: %d\n", result3);

	return 0;
}*/
