/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/26 09:43:48 by wngui             #+#    #+#             */
/*   Updated: 2023/06/26 10:26:40 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcat(char *dest, char *src)
{
	char	*ptr;

	ptr = dest;
	while (*ptr)
		ptr++;
	while (*src)
		*ptr++ = *src++;
	*ptr = '\0';
	return (dest);
}
/*
#include <stdio.h>

char	*ft_strcat(char *dest, char *src);

int	main(void)
{
	char dest[50] = "Hello, ";
	char *src = "world!";

	ft_strcat(dest, src);

	printf("%s\n", dest);

	return 0;
}*/
